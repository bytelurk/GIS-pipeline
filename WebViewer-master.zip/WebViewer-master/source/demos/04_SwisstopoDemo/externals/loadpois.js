/**
 * @description 
 */
function loadpois(poilayer)
{
poidef = {//icon     :"../images/city.png",
               text 		:"Zürich",
               position : [8.536931264729185,47.377116183566265,628.1],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);



poidef = {//icon     :"../images/city.png",
               text 		:"Genf",
               position : [6.143043032744171,46.20481474003789,386.3],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);



poidef = {//icon     :"../images/city.png",
               text 		:"Basel",
               position : [7.5943732226713045,47.55458753100542,344.6],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);



poidef = {//icon     :"../images/city.png",
               text 		:"Bern",
               position : [7.394904402686759,46.954607881295885,614.9],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = {//icon     :"../images/city.png",
               text 		:"Lausanne",
               position : [6.652439268513288,46.51361360319844,400.0],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = {//icon     :"../images/city.png",
               text 		:"Winterthur",
               position : [8.73327681269034,47.49887672128885,528.7],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = {//icon     :"../images/city.png",
               text 		:"Luzern",
               position : [8.282197154236883,47.05472354776679,948.0],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = {//icon     :"../images/city.png",
               text 		:"Lugano",
               position : [8.955567481754757,46.009283291478546,278.5],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = {//icon     :"../images/city.png",
               text 		:"Biel/Bienne",
               position : [7.25689839297117,47.14957923074727,588.5],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = {//icon     :"../images/city.png",
               text 		:"Thun",
               position : [7.638186654609935,46.740393206318736,629.2],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = {//icon     :"../images/city.png",
               text 		:"Köniz",
               position : [7.414912142065437,46.924389835305185,572.1],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = {//icon     :"../images/city.png",
               text 		:"La Chaux-de-Fonds",
               position : [6.819920255711463,47.09501906170322,1198.1],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);



poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Freiburg",
               position : [7.159796188299132,46.80321350365656,596.4],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);




poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Schaffhausen",
               position : [8.648029453075534,47.70879789803077,439.7],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Chur",
               position : [9.53284130117194,46.85291167051996,1227.6],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);



poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Neuenburg",
               position : [6.942469689427836,46.996723,529.0],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Vernier",
               position : [6.105948917760189,46.208877365282916,419.9],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);

poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Uster",
               position : [8.71818602780866,47.35046831003612,463.8],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Sitten",
               position : [7.365283978567222,46.23029634410609,477.0],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Lancy",
               position : [6.121518360879281,46.185051868925925,403.8],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);




poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Emmen",
               position : [8.280842608380144,47.08832723198705,557.6],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Rapperswil-Jona",
               position : [8.85744696275554,47.22954979751591,511.6],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = poidef = {//icon     :"../images/city.png",
               text 		:"St. Gallen",
               position : [9.369383524422805,47.423872100074156,670.1],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);



poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Kriens",
               position : [8.279105407769158,47.032972459316376,490.9],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);



poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Yverdon-les-Bains",
               position : [6.641027082863277,46.781200059314806,434.5],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Zug",
               position : [8.511257067184395,47.17484428502658,418.9],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Montreux",
               position : [6.911661505932166,46.43319387979751,391.7],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Dübendorf",
               position : [8.623088810839647,47.40014752333883,438.4],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);


poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Dietikon",
               position : [8.404799519454894,47.405946988136755,388.5],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);

poidef = poidef = {//icon     :"../images/city.png",
               text 		:"Frauenfeld",
               position : [8.896843854953772,47.559801366049676,397.4],
               size 		: 	10,
               flagpole : false
               ,visibilityRange : [5,100] };
 var poi = ogCreatePOI(poilayer,poidef);



//poi ruschein für stefan...
}













