All default shaders are embedded in the engine (shaders.js)
Here you find the (human readable) non-embedded versions of the shaders.

With the application "ShaderToJS" you can generate embedded shaders by simply running the application in the shader directory.
