The conversion script requires ImageMagick
Input Files are always .tif with alpha channel

