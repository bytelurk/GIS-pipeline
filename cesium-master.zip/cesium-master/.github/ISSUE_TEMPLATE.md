Thanks for contributing to the Cesium Community!

If you have a question, please search the forum:

http://cesiumjs.org/forum.html

and start a new forum thread, if needed, instead of creating this issue.

Otherwise, we look forward to your bug report or feature request in this issue.

---

Delete this message before clicking Submit.